#include <stdio.h>
#include <stdlib.h>

#include "Branch.h"

int initBranch(Branch* branch) {

	if (!branch)
		return 0;
	initAddress(&branch->address);
	branch->branchID = branchID_generator;
	branchID_generator++;
	return 1;
}

int compareByID(const void* b1, const void* b2) {
	Branch* br1 = (Branch*)b1;
	Branch* br2 = (Branch*)b2;

	return br1->branchID - br2->branchID;
}

void printBranch(const void* b) {
	Branch* branch = (Branch*)b;
	if (!branch)
		return;
	printf("Branch ID: %d\nBranch Address: ", branch->branchID);
	printAddress(&branch->address);
}

void freeBranch(Branch* branch)
{
	freeAddress(&branch->address);
}
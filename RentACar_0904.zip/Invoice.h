#pragma once
#define START_SN_INVOICE 0
#include "Date.h"
static int invoiceSN_generator = START_SN_INVOICE;

typedef struct {
    int invoiceSN;
    int rentalSN;
    float totalAmount;
    Date issueDate;
}Invoice;

Invoice* createInvoice(float amount, int rentalSerial);
void printInvoice(const Invoice* invoice);
void updateInvoice(Invoice* invoice, float updateCost);

//nothing to free
#pragma once
#define START_SN_INSUR 0
static unsigned int InsuranceSN_generator = START_SN_INSUR;

typedef enum { eLiability, eCollision, eRoadside, ePersonal, eComprehensive, eNumTypes } eType;
static const char* types[eNumTypes] = { "Liability", "Collision Damage Waiver", "Roadside Assistance", "Personal Accident", "Comprehensive" };
static const int costs[eNumTypes] = { 12,20,18,22,30 };

typedef struct {
    unsigned int InsuranceSN; // -> From 0 - 9999 -> 14 bits
    eType type; // 5 option for type -> 3 bits
    unsigned int costPerDay; // Max cost per day is 30 -> 5 bits
    // Total 3 bytes for compressed file
}Insurance;

Insurance* createInsurance();
eType getInsuranceType();
const char* GetTypeStr(int type);
void printInsurance(const Insurance* insurance);

//nothing to free